//Groovy Version: 2.5.4
//do not place package here, no need
//main method must be in class Dcoder

import java.io.File
class Dcoder {
  static void main(String[] args) {
    println("Hello, Dcoder");
  }
}(0)temp script noel.stamp 
(72)null.zone else.verdansk

{68}fad.dir full.method 

nash.pull over

(dansk)