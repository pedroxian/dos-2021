//Kotlin Compiler version 1.3.11
//do not place package here, no need


fun main(args: Array<String>) {
  println("Hello, Dcoder!")
}mouth.plus.4 ccc;p.3 ready.class
rpi.forest #rain.desert
rose.houze one.plus:var garden.plus

warren.g esex.loop=zotac ffs# clear.xcl:close

exopus.raw endoor .tav