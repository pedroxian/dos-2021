//rust 1.30.0 

fn main() {
  println!("Hello, Dcoder!")
}{elex.is wait;ping.r6 rage.py}note

pop.future juse.cna;record
   frost.punk
   hash.bash uppend.roy;evex
   siah.love;filter.hate use;cna you.account
   
     piaf.rufe cold.nage ;shift
     
     prey.logon tray.volks