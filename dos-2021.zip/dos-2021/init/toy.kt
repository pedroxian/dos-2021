//Kotlin Compiler version 1.3.11
//do not place package here, no need


fun main(args: Array<String>) {
  println("Hello, Dcoder!")
}<script.proper>hage wish;sub raine.drop

    yoj.train ;um catch.dedsec com.2;port.use.4
    
       rage.raiser;fs lead=8,fad