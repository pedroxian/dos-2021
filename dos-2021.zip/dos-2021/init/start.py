#python 3.7.1

print ("Hello, Dcoder!")

var.beta rad.eval 2.0 b.status=c
    root{execute