--ghc 8.6.3

main = putStrLn "Hello, Dcoder!"

rasputin.orge mouth.sith connect;siege
back.hack if.groush made.op ;os.create vil.code

else.it true.local;ct use.kernels trage.os

tails.tail matik;math.cad